# ACOMA: Optimisation-Based Band Selection for Sentinel-2 Compression
*Generated 2026-11-16 from the result files in `/kaggle/working/acoma_test_out`. All numbers below are computed from those files.*

## Abstract
Sentinel-2 patches have 13 spectral bands, and transmitting all of them is costly. ACOMA selects a subset of k bands to compress and transmit, and predicts the remaining bands on the ground by linear regression. Band selection is posed as a combinatorial problem with a fitness that combines reconstruction error, the real bitrate of a JPEG2000 codec, and a redundancy penalty. Because 13 bands give a small search space, exhaustive search provides the true optimum, and it is used to measure how close a Genetic Algorithm (GA), binary Particle Swarm Optimisation (BPSO), a GA-PSO hybrid and random search get under equal fitness-evaluation budgets. Subsets are chosen on 26 patches from training regions, and the final evaluation uses 396 patches from 6 independent test regions that are never used during selection.

**Headline search result.** Budget 400 (23% of the space), mean gap to the optimum, best first: hybrid 0.0152% (optimum found in 93.3% of runs); bpso 0.018% (optimum found in 96.7% of runs); ga 0.0361% (optimum found in 93.3% of runs); random 0.899% (optimum found in 10% of runs).

## 1. Motivation
Onboard compression of multispectral imagery trades downlink bandwidth against fidelity. Sending fewer bands cuts the bitrate directly, but only helps if the dropped bands can be recovered well enough for downstream use. Which bands to keep is a discrete selection problem. This project studies that problem on Sentinel-2 data and compares exhaustive, evolutionary and swarm search against each other on a common footing.

## 2. Background and related work
The project builds on three papers supplied to the team.

- **Learned onboard compression (Gomez et al., CVPRW 2024).** Trains scale-hyperprior autoencoders on 13-channel Sentinel-2 data in a merged mode (all bands jointly) and a split mode (a shared model applied per band), with JPEG as a baseline. This is the team's Approaches 1 and 2.
- **Deep-learning band selection review (Ding et al., 2026).** Reviews autoencoder-based band selection and ways of handling the discrete selection, and states that the field lacks standard benchmarks and standard efficiency reporting. Our common metric set and fixed protocol respond to that.
- **Dimensionality reduction in hyperspectral remote sensing (Vaddi et al., 2024).** Reviews feature extraction and band selection, including combinatorial-optimisation and evolutionary band selection. It notes that exhaustive search is impractical for hundreds of hyperspectral bands but more feasible for multispectral data, and that tuning evolutionary searches is hard. ACOMA takes from it the framing of band selection as a combinatorial optimisation over band subsets, but uses its own objective: regression-based reconstruction of all bands, an explicit codec-rate term and a redundancy term. It does not reproduce the neighbour-reconstruction and entropy formulation of the paper's Algorithm 1.

The optimisers are standard: the genetic algorithm (Holland, 1975) and the binary version of particle swarm optimisation (Kennedy and Eberhart, 1997). JPEG2000 is ISO/IEC 15444-1.

## 3. Problem formulation
Let X have B = 13 bands. A candidate is a binary vector b with exactly k ones (equivalently, a set S of k band indices). The objective is

    J(b) = D(X, X_hat_b) + mu * Rn(b) + nu * Red(b),    subject to sum_i b_i = k

- **D** is the mean over all 13 bands of the squared error divided by that band's variance on the fitting data. For a selected band the error is the JPEG2000 codec error. For a missing band it is the error of a linear regression (with intercept) fitted on the fitting patches and applied to the decoded selected bands. Predictions are clipped to the valid range.
- **Rn** is the compressed size of the selected bands divided by that of all 13 bands at the same codec rate.
- **Red** is the mean absolute correlation between the selected bands. This is our own proxy for redundancy; Vaddi et al. mention a mean spectral divergence but do not define it in the text, so we do not claim to reproduce it.

For k = 6 or 7 there are C(13, k) = 1,716 candidates, which is the largest case for a fixed k. (The figure of 8,191 sometimes quoted counts non-empty subsets of every size.)

## 4. Method
**Per-band codec cache.** Each band is compressed separately with JPEG2000 (Pillow/OpenJPEG, irreversible 9/7 wavelet, a target compression ratio relative to 16-bit raw). Per-band bytes and codec error are computed once, so any subset's rate and codec distortion are sums over its bands. This is exact for independent per-band coding and is not valid for joint multi-band coding.

**Algorithms.** *Exhaustive* scores every subset. *GA* uses a population of 20, tournament selection, crossover that keeps shared bands and fills the rest from the parents' symmetric difference, swap mutation and one elite. *BPSO* uses 20 particles, inertia 0.7, c1 = c2 = 1.5, a sigmoid transfer function and repair to exactly k bands. *Hybrid* runs the GA for half the budget and then starts BPSO from the GA's best individuals, with the seed re-evaluations counted. *Random* search samples subsets uniformly.

**Fair comparison.** One evaluation is one call to the fitness, including repeated candidates. Every method stops at exactly the same budget, with the same seeds list, and the cache only saves computation.

## 5. Experimental setup
Data: 13-band, 512 x 512, uint16 `.npy` patches. Search splits are made within trainval at region level; the independent test dataset is not used for selection:

| group | patches |
|---|---|
| fit (regression) | 26 |
| eval (search fitness) | 26 |
| dev (held-out train regions) | 26 |
| independent test (final report) | 1584 |

Dev regions: maldives, sahara_algeria. Independent test regions: everest_region, great_barrier_reef, lagos, northern_sweden, po_valley, rub_al_khali. Seed 0.

Settings: mu = 0.5, nu = 0.1, main codec rate = 8, main k = 6, pixels sampled per patch = 5000, rates swept = [4, 8, 16, 32], k swept = [3, 4, 5, 6, 7, 8, 10], budgets = [100, 200, 400], seeds = 30.

Per-band statistics on a pixel sample from fitting and evaluation patches (uint16 digital numbers):

| band | mean | std | p99 | max |
|---|---|---|---|---|
| 0 | 2669.5 | 1306.5 | 9826 | 11607 |
| 1 | 2457.8 | 1369.3 | 9861 | 12037 |
| 2 | 2335.4 | 1301.7 | 9187 | 15093 |
| 3 | 2262.8 | 1479.1 | 9764 | 19233 |
| 4 | 2476.5 | 1428.4 | 9780 | 13313 |
| 5 | 3206.6 | 1441.9 | 9825 | 18097 |
| 6 | 3552.2 | 1535.1 | 9569 | 22155 |
| 7 | 3460.3 | 1484.4 | 9167 | 16412 |
| 8 | 3741.5 | 1598.4 | 9444 | 19082 |
| 9 | 1859.9 | 741.46 | 5263 | 6913 |
| 10 | 1027.4 | 44.385 | 1224 | 1441 |
| 11 | 2655.6 | 956.83 | 5663 | 13965 |
| 12 | 2061.9 | 794.05 | 4477 | 13990 |

![Band correlation](fig_band_corr.png)

The band index order is taken as given in the data files. It has not been checked against the Sentinel-2 band names, so the report refers to bands by index only.

## 6. Results
### 6.1 Search algorithms against the exhaustive optimum
| method | budget | mean gap % | median gap % | optimum found (fraction of runs) | median rank | median evals to optimum |
|---|---|---|---|---|---|---|
| random | 100 | 1.65 | 1.779 | 0.06667 | 11 | 45.5 |
| random | 200 | 1.328 | 1.365 | 0.03333 | 7 | 96 |
| random | 400 | 0.8994 | 0.8012 | 0.1 | 4 | 254 |
| ga | 100 | 0.506 | 0.228 | 0.3333 | 1 | 69 |
| ga | 200 | 0.1808 | 0 | 0.7 | 0 | 120 |
| ga | 400 | 0.03609 | 0 | 0.9333 | 0 | 126.5 |
| bpso | 100 | 0.8574 | 0.5414 | 0.2333 | 2 | 51 |
| bpso | 200 | 0.04084 | 0 | 0.8667 | 0 | 126.5 |
| bpso | 400 | 0.01805 | 0 | 0.9667 | 0 | 109 |
| hybrid | 100 | 1.229 | 1.297 | 0.1 | 6.5 | 92 |
| hybrid | 200 | 0.2339 | 0 | 0.6667 | 0 | 156.5 |
| hybrid | 400 | 0.0152 | 0 | 0.9333 | 0 | 123.5 |

Gap = (J_found - J_optimum) / J_optimum. Rank 0 is the true optimum.

![Search](fig_search.png)

- The exhaustive oracle scored all 1716 subsets with k = 6; each stochastic method was run with 30 seeds at each budget, and every call to the fitness counts against the budget.
- Budget 100 (6% of the space), mean gap to the optimum, best first: ga 0.506% (optimum found in 33.3% of runs); bpso 0.857% (optimum found in 23.3% of runs); hybrid 1.23% (optimum found in 10% of runs); random 1.65% (optimum found in 6.67% of runs).
- At budget 100, ga vs random search: one-sided Mann-Whitney U p = 1.99e-06 (gap significantly smaller at the 0.05 level).
- At budget 100, bpso vs random search: one-sided Mann-Whitney U p = 0.00055 (gap significantly smaller at the 0.05 level).
- At budget 100, hybrid vs random search: one-sided Mann-Whitney U p = 0.0205 (gap significantly smaller at the 0.05 level).
- At budget 100, GA vs BPSO: two-sided p = 0.126.
- Budget 200 (12% of the space), mean gap to the optimum, best first: bpso 0.0408% (optimum found in 86.7% of runs); ga 0.181% (optimum found in 70% of runs); hybrid 0.234% (optimum found in 66.7% of runs); random 1.33% (optimum found in 3.33% of runs).
- At budget 200, ga vs random search: one-sided Mann-Whitney U p = 2.56e-09 (gap significantly smaller at the 0.05 level).
- At budget 200, bpso vs random search: one-sided Mann-Whitney U p = 1.83e-11 (gap significantly smaller at the 0.05 level).
- At budget 200, hybrid vs random search: one-sided Mann-Whitney U p = 1.3e-08 (gap significantly smaller at the 0.05 level).
- At budget 200, GA vs BPSO: two-sided p = 0.096.
- Budget 400 (23% of the space), mean gap to the optimum, best first: hybrid 0.0152% (optimum found in 93.3% of runs); bpso 0.018% (optimum found in 96.7% of runs); ga 0.0361% (optimum found in 93.3% of runs); random 0.899% (optimum found in 10% of runs).
- At budget 400, ga vs random search: one-sided Mann-Whitney U p = 1.57e-10 (gap significantly smaller at the 0.05 level).
- At budget 400, bpso vs random search: one-sided Mann-Whitney U p = 6.75e-11 (gap significantly smaller at the 0.05 level).
- At budget 400, hybrid vs random search: one-sided Mann-Whitney U p = 8.59e-11 (gap significantly smaller at the 0.05 level).
- At budget 400, GA vs BPSO: two-sided p = 0.57.

### 6.2 Best subsets found by exhaustive search (top 10)
| rank | bands | D | Rn | bpp | Red | J |
|---|---|---|---|---|---|---|
| 0 | (0, 8, 9, 10, 11, 12) | 0.006216 | 0.4223 | 0.7857 | 0.4162 | 0.259 |
| 1 | (0, 6, 9, 10, 11, 12) | 0.00606 | 0.4223 | 0.7858 | 0.4234 | 0.2596 |
| 2 | (1, 8, 9, 10, 11, 12) | 0.004331 | 0.4273 | 0.7949 | 0.4242 | 0.2604 |
| 3 | (0, 7, 9, 10, 11, 12) | 0.007252 | 0.4223 | 0.7858 | 0.4241 | 0.2608 |
| 4 | (1, 6, 9, 10, 11, 12) | 0.004255 | 0.4273 | 0.7951 | 0.4314 | 0.261 |
| 5 | (2, 8, 9, 10, 11, 12) | 0.004099 | 0.4272 | 0.7948 | 0.4378 | 0.2615 |
| 6 | (2, 6, 9, 10, 11, 12) | 0.00405 | 0.4272 | 0.7949 | 0.4448 | 0.2622 |
| 7 | (1, 7, 9, 10, 11, 12) | 0.005616 | 0.4273 | 0.795 | 0.4324 | 0.2625 |
| 8 | (0, 5, 9, 10, 11, 12) | 0.007332 | 0.4224 | 0.7859 | 0.4435 | 0.2629 |
| 9 | (0, 2, 8, 9, 10, 11) | 0.005966 | 0.4222 | 0.7856 | 0.4641 | 0.2635 |

### 6.3 Effect of the rate weight mu
This sweep shows the trade-off between reconstruction error and bits as mu changes. It is not a search for a best mu.

| mu | bands | D | Rn | bpp | Red | J |
|---|---|---|---|---|---|---|
| 0 | (1, 8, 9, 10, 11, 12) | 0.004331 | 0.4273 | 0.7949 | 0.4242 | 0.04675 |
| 0.25 | (0, 8, 9, 10, 11, 12) | 0.006216 | 0.4223 | 0.7857 | 0.4162 | 0.1534 |
| 0.5 | (0, 8, 9, 10, 11, 12) | 0.006216 | 0.4223 | 0.7857 | 0.4162 | 0.259 |
| 1 | (0, 8, 9, 10, 11, 12) | 0.006216 | 0.4223 | 0.7857 | 0.4162 | 0.4701 |
| 2 | (0, 8, 9, 10, 11, 12) | 0.006216 | 0.4223 | 0.7857 | 0.4162 | 0.8924 |

### 6.4 Generalisation to held-out training regions
| k | best on eval | best on dev | gap on dev % | rank on dev | of |
|---|---|---|---|---|---|
| 3 | (5, 10, 12) | (6, 10, 11) | 3.118 | 3 | 286 |
| 4 | (0, 8, 10, 11) | (2, 8, 10, 12) | 19.84 | 37 | 715 |
| 5 | (0, 8, 9, 10, 11) | (0, 4, 8, 9, 10) | 21.17 | 155 | 1287 |
| 6 | (0, 8, 9, 10, 11, 12) | (2, 3, 6, 9, 10, 11) | 8.198 | 25 | 1716 |
| 7 | (0, 1, 8, 9, 10, 11, 12) | (1, 3, 6, 9, 10, 11, 12) | 16.27 | 149 | 1716 |
| 8 | (0, 1, 7, 8, 9, 10, 11, 12) | (0, 1, 3, 6, 9, 10, 11, 12) | 17.17 | 278 | 1287 |
| 10 | (0, 1, 3, 6, 7, 8, 9, 10, 11, 12) | (0, 2, 3, 5, 7, 8, 9, 10, 11, 12) | 6.28e-04 | 1 | 286 |

The subset chosen on the eval patches had a mean gap of 12.3% and a worst gap of 21.2% against the dev-region optimum, and was the dev optimum for 0 of 7 values of k.

### 6.5 Rate-distortion on the independent test regions (13-band space)
Codec rate 8, all methods. The full set of rates is in `final_table.csv`.

| method | k | bands | bpp | CR | PSNR dB | SSIM | SAM deg | rel. err | encode s | decode s |
|---|---|---|---|---|---|---|---|---|---|---|
| acoma | 3 | (5, 10, 12) | 0.3575 | 45.4 | 41.64 | 0.9593 | 11.78 | 0.1815 | 0.127 | 0.07593 |
| even | 3 | (0, 6, 12) | 0.4489 | 35.76 | 48.91 | 0.9916 | 4.226 | 0.06365 | 0.1459 | 0.08484 |
| var | 3 | (3, 6, 8) | 0.4606 | 34.74 | 43.46 | 0.9776 | 9.105 | 0.1197 | 0.1835 | 0.08133 |
| acoma | 4 | (0, 8, 10, 11) | 0.4993 | 32.45 | 47.26 | 0.9858 | 5.119 | 0.09443 | 0.1577 | 0.08613 |
| even | 4 | (0, 4, 8, 12) | 0.6025 | 26.61 | 51.29 | 0.9939 | 3.302 | 0.04705 | 0.2046 | 0.09497 |
| var | 4 | (3, 4, 6, 8) | 0.6141 | 26.05 | 43.62 | 0.9781 | 8.931 | 0.1133 | 0.2415 | 0.09723 |
| acoma | 5 | (0, 8, 9, 10, 11) | 0.6397 | 25.41 | 49.44 | 0.9918 | 4.031 | 0.05683 | 0.1863 | 0.1019 |
| even | 5 | (0, 3, 6, 9, 12) | 0.7428 | 21.66 | 54 | 0.9972 | 2.259 | 0.02975 | 0.2362 | 0.1103 |
| var | 5 | (3, 4, 5, 6, 8) | 0.7677 | 20.84 | 44.25 | 0.9802 | 8.215 | 0.1053 | 0.301 | 0.1073 |
| acoma | 6 | (0, 8, 9, 10, 11, 12) | 0.7932 | 20.38 | 50.76 | 0.9935 | 3.592 | 0.04434 | 0.2436 | 0.1132 |
| bpso | 6 | (0, 8, 9, 10, 11, 12) | 0.7932 | 20.38 | 50.76 | 0.9935 | 3.592 | 0.04434 | 0.2436 | 0.1132 |
| even | 6 | (0, 2, 5, 7, 10, 12) | 0.8063 | 19.94 | 50.32 | 0.9911 | 4.76 | 0.05978 | 0.2789 | 0.113 |
| ga | 6 | (0, 8, 9, 10, 11, 12) | 0.7932 | 20.38 | 50.76 | 0.9935 | 3.592 | 0.04434 | 0.2436 | 0.1132 |
| hybrid | 6 | (0, 8, 9, 10, 11, 12) | 0.7932 | 20.38 | 50.76 | 0.9935 | 3.592 | 0.04434 | 0.2436 | 0.1132 |
| random | 6 | (0, 8, 9, 10, 11, 12) | 0.7932 | 20.38 | 50.76 | 0.9935 | 3.592 | 0.04434 | 0.2436 | 0.1132 |
| var | 6 | (3, 4, 5, 6, 7, 8) | 0.9212 | 17.37 | 44.34 | 0.9809 | 8.109 | 0.1029 | 0.3656 | 0.1244 |
| acoma | 7 | (0, 1, 8, 9, 10, 11, 12) | 0.9468 | 17.02 | 52.47 | 0.9965 | 3.196 | 0.03476 | 0.3015 | 0.1249 |
| even | 7 | (0, 2, 4, 6, 8, 10, 12) | 0.9599 | 16.73 | 52.49 | 0.9959 | 3.044 | 0.03867 | 0.3346 | 0.125 |
| var | 7 | (1, 3, 4, 5, 6, 7, 8) | 1.075 | 14.89 | 48.85 | 0.9915 | 4.105 | 0.05489 | 0.4234 | 0.1297 |
| acoma | 8 | (0, 1, 7, 8, 9, 10, 11, 12) | 1.1 | 14.62 | 53.19 | 0.9969 | 3.033 | 0.03298 | 0.366 | 0.1367 |
| even | 8 | (0, 2, 3, 5, 7, 9, 10, 12) | 1.1 | 14.62 | 55.34 | 0.9985 | 1.943 | 0.01955 | 0.3691 | 0.1363 |
| var | 8 | (0, 1, 3, 4, 5, 6, 7, 8) | 1.217 | 13.16 | 48.91 | 0.9915 | 4.101 | 0.05309 | 0.4515 | 0.1484 |
| acoma | 10 | (0, 1, 3, 6, 7, 8, 9, 10, 11, 12) | 1.407 | 11.4 | 60.92 | 0.9992 | 1.155 | 0.0128 | 0.4882 | 0.1721 |
| even | 10 | (0, 1, 3, 4, 5, 7, 8, 9, 11, 12) | 1.51 | 10.61 | 63.3 | 0.9988 | 0.9422 | 0.01348 | 0.535 | 0.1808 |
| var | 10 | (0, 1, 2, 3, 4, 5, 6, 7, 8, 11) | 1.524 | 10.5 | 54.42 | 0.9956 | 2.651 | 0.03368 | 0.569 | 0.1777 |
| all13 | 13 | (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12) | 1.868 | 8.581 | 69.98 | 0.9997 | 0.4499 | 0.0058 | 0.665 | 0.1942 |

![Rate-distortion](fig_rate_distortion.png)

- Against the variance-ranking baseline (28 (rate, k) pairs, 0 with an identical band set): ACOMA had higher PSNR in 24 of 28 and lower SAM in 24 of 28 differing pairs; median bpp ratio ACOMA/baseline = 0.892. Because the subsets differ in bits, compare PSNR and SAM together with bpp, not alone.
- Against the evenly-spaced baseline (28 (rate, k) pairs, 0 with an identical band set): ACOMA had higher PSNR in 4 of 28 and lower SAM in 4 of 28 differing pairs; median bpp ratio ACOMA/baseline = 0.947. Because the subsets differ in bits, compare PSNR and SAM together with bpp, not alone.
- Across the 28 ACOMA subsets (all rates and k), the most frequently selected band indices were 10 (28x), 11 (25x), 8 (24x), 9 (20x).

![Band frequency](fig_band_freq.png)

## 7. Comparison across the four team approaches
`common_metrics_acoma.csv` holds ACOMA's results in a shared column schema so the four approaches can be merged and plotted together on the same rate-distortion and cost axes. The rows for Approaches 1 to 3 are to be filled from the teammates' own runs, using the same independent test patches and the same PSNR maximum and bit-depth convention.

| approach | status |
|---|---|
| 1: CompressAI merged | pending (teammate) |
| 2: CompressAI split | pending (teammate) |
| 3: independent approach | pending (teammate) |
| 4: ACOMA | see common_metrics_acoma.csv |

## 8. Discussion
The discussion is limited to what the result files support.

- The search space is small enough for exhaustive search. Whether GA or BPSO is useful therefore depends on cost: they are only worthwhile if they reach near-optimal subsets using far fewer evaluations, or if the problem is enlarged (more bands, joint coding, or an expensive per-subset codec). The budget table in 6.1 shows how far each method got at each share of the space.
- Using the actual codec rate inside the fitness couples the selection to the codec in use. Subsets chosen at one rate need not be best at another, and that is why the final stage reselects at every rate.
- Reconstruction of missing bands is linear. If a band is poorly predicted by the selected ones, its error is inherited by every downstream metric, and the band-frequency plot shows which bands the optimiser could not afford to drop.
## 9. Limitations and threats to validity
- **Fitness is estimated from samples.** Reconstruction error of missing bands is computed on a pixel sample from the eval patches; per-band codec error and bytes use full images. A unit test checks that this agrees closely with full-image reconstruction on synthetic data, but it has not been separately checked on the real data.
- **Independent per-band coding.** Rate additivity holds only for per-band coding. A codec that exploits inter-band redundancy would need re-evaluation per subset and would change the cost of exhaustive search.
- **Linear prediction.** Non-linear predictors (for example a small network) might reconstruct missing bands better and shift the optimal subsets.
- **Selection data.** Subsets are selected on a few dozen patches from training regions and confirmed only on two held-out regions in the dev check; independent test regions are used once, for the final report.
- **Fitness is not PSNR or SAM.** D is a variance-normalised squared error averaged over bands, so a subset that minimises J need not win on PSNR, SSIM or SAM. The final tables report all of them and the text states where each baseline wins.
- **Redundancy proxy and fixed weights.** The redundancy term is a correlation proxy, and mu and nu are fixed, not tuned.
- **Bit-depth and PSNR convention.** bpp and compression ratio are relative to the 16-bit container. PSNR uses a fixed maximum set in `acoma_core.PSNR_MAX`. Both must match across the four approaches before comparing them.
- **Codec implementation.** JPEG2000 comes from Pillow/OpenJPEG with a target-ratio rate control; the achieved ratio can differ slightly from the target.
- **No flight-standard baseline.** CCSDS 123.0-B-2, which paper A lists as missing, is not included.
- **Single dataset.** Conclusions are for this dataset's regions and imaging conditions.

## 10. Reproducibility
Run `acoma_kaggle.ipynb` or `python acoma_driver.py` followed by `python make_report.py <out>`. All randomness uses fixed seeds, the region-level splits are saved in `splits.json`, and the configuration is saved in `config.json`. The unit tests (`tests_*.py`) check metrics, split disjointness, codec round trip, budget accounting and the agreement between fitness and full-image reconstruction.

## References
- Gomez et al., CVPR Workshops, 2024, pp. 6809-6818 (learned onboard compression of Sentinel-2).
- Ding et al., 2026, deep-learning band selection review (as supplied to the team; check the final citation details).
- Vaddi, Phaneendra Kumar, Manoharan, Agilandeeswari, Sangeetha, 2024. Strategies for dimensionality reduction in hyperspectral remote sensing: a comprehensive overview. Egyptian Journal of Remote Sensing and Space Sciences 27, 82-92.
- Balle et al., variational image compression with a scale hyperprior, ICLR 2018 (as cited in paper A).
- Holland, J. H., Adaptation in Natural and Artificial Systems, 1975.
- Kennedy, J. and Eberhart, R., A discrete binary version of the particle swarm algorithm, IEEE SMC, 1997.
- ISO/IEC 15444-1, JPEG 2000 image coding system, core coding system.
